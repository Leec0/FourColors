module be.fourcolors {
    requires javafx.controls;
    exports be.fourcolors.console;
    exports be.fourcolors.mvp;
}