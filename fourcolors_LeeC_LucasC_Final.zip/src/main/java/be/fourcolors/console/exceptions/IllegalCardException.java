package be.fourcolors.console.exceptions;

public class IllegalCardException extends Exception {
    public IllegalCardException(String reason) {
        super(reason);
    }
}
