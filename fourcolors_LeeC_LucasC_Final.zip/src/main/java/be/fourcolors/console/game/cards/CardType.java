package be.fourcolors.console.game.cards;

public enum CardType {
    DRAW2, REVERSE, SKIP, DRAW4, CHANGE
}

