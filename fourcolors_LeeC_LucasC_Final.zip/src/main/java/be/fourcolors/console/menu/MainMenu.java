package be.fourcolors.console.menu;

public class MainMenu {
}
