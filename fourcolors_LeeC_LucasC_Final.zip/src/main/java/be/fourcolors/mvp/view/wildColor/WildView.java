package be.fourcolors.mvp.view.wildColor;

import javafx.scene.layout.GridPane;

public class WildView extends GridPane {

    public WildView() {

    }
}
