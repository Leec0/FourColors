package fourcolors.exceptions;

public class IllegalCardTurnException extends Exception {
    public IllegalCardTurnException(String reason) {
        super(reason);
    }
}
