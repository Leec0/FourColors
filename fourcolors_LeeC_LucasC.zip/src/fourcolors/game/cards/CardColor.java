package fourcolors.game.cards;

public enum CardColor {
    RED, GREEN, BLUE, YELLOW, WILD
}
