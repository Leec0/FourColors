package fourcolors.menu;

public class MainMenu {
}
